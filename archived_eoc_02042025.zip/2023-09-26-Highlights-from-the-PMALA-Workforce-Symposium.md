---
title: 'PMA Learning Agenda: Highlights from the PMALA Workforce Symposium'
year: 2023
description: 
doc-link: assets/resources/PMA Learning Agenda Workforce Symposium.pdf
aria-label: PMA Learning Agenda Workforce Symposium
content_tags:
type: pdf
filters: report 2023 evidence-use omb
post-date: September 27, 2023 # # must add post date to show the "new" icon
---
